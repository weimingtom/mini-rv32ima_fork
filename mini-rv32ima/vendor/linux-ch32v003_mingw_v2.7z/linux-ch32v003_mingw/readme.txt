ESC to exit

----
#ifndef __MINGW32__
// UART receive interrupt handler
void USART1_IRQHandler( void ) __attribute__((interrupt));
void USART1_IRQHandler( void )
{
	if(keys_num <= KEY_QUEUE_LEN)
		key_queue[keys_num++] =  USART1->DATAR;
}
#else
//FIXME:????pthread
#endif


---

#define INSTRS_PER_FLIP 1024
#ifndef __MINGW32__
#define MICROSECOND_TICKS ( SysTick->CNT / DELAY_US_TIME )
#else
#include <windows.h>
#define MICROSECOND_TICKS (GetTickCount_(0))
uint64_t kkk = 0;
//https://blog.csdn.net/liulilittle/article/details/135062513 
uint64_t GetTickCount_(int microseconds) {
#ifdef __MINGW32__
#if 1
	//at least 10000 per step
	//return kkk+=10000; //GetTickCount();
	//return kkk = GetTickCount() * 10000;
	//FIXME: if this return too small, HandleOtherCSRRead will wait too long time and no input
	return GetTickCount() * 1000 * 1000;
#else

----

//FIXME:????pthread
void USART1_IRQHandler( void )
{
	char k = _getch();
	if(keys_num <= KEY_QUEUE_LEN)
		key_queue[keys_num++] =  k;
	if (/*k == '~' || k == '`' ||*/ k == 27 /*ESC*/ ) exit(0);	
#if 0	
	printf(">>>>%d\n", k);
	fflush(stdout);
#else
	printf("%c", k);
	fflush(stdout);
#endif	
}
#endif

