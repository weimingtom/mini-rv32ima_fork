# Cachetest (incomplete/GPU Only)

Playing with the idea of being able to have a cache, for systems where main system RAM access is slow.

This cache is intended to run on the GPU, so it doesn't line up to what most people would want to do on simulating embedded systems.
