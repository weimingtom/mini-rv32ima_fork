
Run `make profile` 

Inside machine: POWEROFF@0x00000000078bdb8c


Note: baseline for c6a2f570e522f99eca178bf534b1554f7791b31a
POWEROFF@0x00000001ea5f51c9 >> Regular
POWEROFF@0x00000001ea4f5226 >> Regular

POWEROFF@0x00000001ea5338e6 >> Tweaked CSR storage.
POWEROFF@0x00000001e770f060 >> With goto's.
POWEROFF@0x00000001e77a25c7 >> Another goto.
POWEROFF@0x00000001e76a759d >> Few tweaks

All of these were done with function calls:
POWEROFF@0x00000001ecc0a2a7 >> With function calls.
POWEROFF@0x00000001ecbe1f5d >> More optimizations with function calls.
POWEROFF@0x00000001ecbd0947 >> Why different?
POWEROFF@0x00000001ecbbad3c >> Why differentttT??
