#include <stdio.h>

int main( int argc, char ** argv )
{
	printf( "Hello, world %08x\n", argc );
	float ft = 7.3f;
	printf( "f: %f\n", ft );
}
